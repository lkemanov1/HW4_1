#include "Message.hpp"

Message::Message(const int data):data(data){}

